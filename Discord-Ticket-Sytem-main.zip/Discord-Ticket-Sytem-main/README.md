# Discord-Ticket-Sytem

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

## Description

Ticket System Discord Bot – your powerful and efficient solution for managing support requests and user inquiries in your Discord server!

# How to Setup?
Watch this toturial and Support me! https://youtu.be/1mldS3L8kOg

**Got any question or Issues with the code?**
__Join:__ https://discord.gg/RFFwqw8B8y
